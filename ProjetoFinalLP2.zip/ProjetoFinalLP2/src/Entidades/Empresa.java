package Entidades;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.HashSet;

public class Empresa {

	private String nome;
	private ArrayList<Funcionario> funcionarios;

	public Empresa(String nome, ArrayList<Funcionario> funcionarios) {
		super();
		this.nome = nome;
		this.funcionarios = funcionarios;
	}

	public ArrayList<Funcionario> getFuncionarios() {
		return funcionarios;
	}

	// Método para adicionar um funcionário
	public void adicionarFuncionario(Funcionario funcionario) {
		funcionarios.add(funcionario);
	}

	// Método para remover um funcionário
	public void removerFuncionario(Funcionario funcionario) {
		funcionarios.remove(funcionario);
	}

	// Método para reajustar o salário de todos os funcionários
	public void reajustarSalario(double percentualAumento) {
		for (Funcionario funcionario : funcionarios) {
			double aumento = funcionario.getSalario() * percentualAumento / 100;
			funcionario.setSalario(funcionario.getSalario() + aumento);
		}
	}

	// Método para reajustar o salário dos funcionários de um determinado setor
	public void reajustarSalario(String setor, double percentualAumento) {
		for (Funcionario funcionario : funcionarios) {
			if (funcionario.getSetor().equalsIgnoreCase(setor)) {
				double aumento = funcionario.getSalario() * percentualAumento / 100;
				funcionario.setSalario(funcionario.getSalario() + aumento);
			}
		}
	}

	// Método para imprimir a lista de funcionários acima da média salarial da
	// empresa
	public void imprimirFuncionariosAcimaMedia() {
	    double mediaSalarial = calcularMediaSalarial();
	    String output = "Funcionários acima da média salarial da empresa:\n";
	    for (Funcionario funcionario : funcionarios) {
	        if (funcionario.getSalario() > mediaSalarial) {
	            output += funcionario.toString() + "\n";
	        }
	    }
	    writeToFile("funcionarios_acima_media.txt", output);
	}

	// Método para imprimir a lista de funcionários por setor
	public void imprimirFuncionariosPorSetor(String setor) {
	    String output = "Funcionários do setor " + setor + ":\n";
	    for (Funcionario funcionario : funcionarios) {
	        if (funcionario.getSetor().equalsIgnoreCase(setor)) {
	            output += funcionario.toString() + "\n";
	        }
	    }
	    writeToFile("funcionarios_por_setor.txt", output);
	}

	// Método para imprimir a lista de funcionários com um determinado número de anos na empresa
	public void imprimirFuncionariosPorAnosNaEmpresa(int anos) {
	    String output = "Funcionários com " + anos + " anos na empresa:\n";
	    for (Funcionario funcionario : funcionarios) {
	        if (funcionario.getAnosNaEmpresa() == anos) {
	            output += funcionario.toString() + "\n";
	        }
	    }
	    writeToFile("funcionarios_por_anos_na_empresa.txt", output);
	}

	// Método para escrever o conteúdo em um arquivo
	private void writeToFile(String filename, String content) {
	    try (FileWriter fileWriter = new FileWriter(filename)) {
	        fileWriter.write(content);
	        System.out.println("Arquivo '" + filename + "' criado com sucesso.");
	    } catch (IOException e) {
	        System.out.println("Erro ao escrever no arquivo: " + e.getMessage());
	    }
	}

// Método para calcular a média salarial da empresa
	public double calcularMediaSalarial() {
		double somaSalarios = 0;
		for (Funcionario funcionario : funcionarios) {
			somaSalarios += funcionario.getSalario();
		}
		return somaSalarios / funcionarios.size();
	}

}