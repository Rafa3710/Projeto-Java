package Entidades;

public class Funcionario {
	private String nome;
	private String setor;
	private double salario;
	private int anosNaEmpresa;

	// Construtor
	public Funcionario(String nome, String setor, double salario, int anosNaEmpresa) {
		this.nome = nome;
		this.setor = setor;
		this.salario = salario;
		this.anosNaEmpresa = anosNaEmpresa;
	}

	// Getters e Setters

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSetor() {
		return setor;
	}

	public void setSetor(String setor) {
		this.setor = setor;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public int getAnosNaEmpresa() {
		return anosNaEmpresa;
	}

	public void setAnosNaEmpresa(int anosNaEmpresa) {
		this.anosNaEmpresa = anosNaEmpresa;
	}

	// Método para obter uma representação em string do funcionário
	@Override
	public String toString() {
		return "Funcionário: " + nome + ", Setor: " + setor + ", Salário: R$" + salario + ", Anos na Empresa: "
				+ anosNaEmpresa;
	}

}